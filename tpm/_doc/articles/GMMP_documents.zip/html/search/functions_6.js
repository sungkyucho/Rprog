var searchData=
[
  ['mallocbody',['MallocBody',['../_g_m_m_p___operation_8c.html#af999eaaca24c546526711fac1d40c873',1,'MallocBody(const char Type, int *nBodySize):&#160;GMMP_Operation.c'],['../_g_m_m_p___operation_8h.html#a3bb6186bbb49f583caaa98bb3c52aff2',1,'MallocBody(const char Type, int *nOutBufferSize):&#160;GMMP_Operation.c']]]
];

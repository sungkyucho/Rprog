var searchData=
[
  ['xtoi',['xtoi',['../_string_table_8c.html#a0c97bc8327f0eec235bd698e771b1a48',1,'xtoi(const char hex):&#160;StringTable.c'],['../_string_table_8h.html#a0c97bc8327f0eec235bd698e771b1a48',1,'xtoi(const char hex):&#160;StringTable.c']]]
];

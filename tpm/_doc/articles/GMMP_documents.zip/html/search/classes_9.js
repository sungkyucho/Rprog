var searchData=
[
  ['notifi_5freq',['Notifi_Req',['../struct_notifi___req.html',1,'']]],
  ['notifi_5frsp',['Notifi_Rsp',['../struct_notifi___rsp.html',1,'']]]
];

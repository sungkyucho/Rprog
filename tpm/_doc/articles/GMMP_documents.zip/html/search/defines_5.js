var searchData=
[
  ['reserved_5fmax',['Reserved_Max',['../_define___control_8h.html#a2848b5ca36f1a8732383caec25179d21',1,'Define_Control.h']]],
  ['reserved_5fmin',['Reserved_Min',['../_define___control_8h.html#a2268b47b072e80b5deb9bbb836f585ca',1,'Define_Control.h']]]
];

var searchData=
[
  ['industrial_5freserved_5fmax',['Industrial_Reserved_Max',['../_define___control_8h.html#a66da91600bb006da852eb257b927b14f',1,'Define_Control.h']]],
  ['industrial_5freserved_5fmin',['Industrial_Reserved_Min',['../_define___control_8h.html#aff6a5b056a786781be259083e8a8693b',1,'Define_Control.h']]]
];

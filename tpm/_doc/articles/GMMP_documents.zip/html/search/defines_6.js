var searchData=
[
  ['status_5fdb_5ftimeout',['STATUS_DB_TIMEOUT',['../_o_m_p_error_code_8h.html#a7d3a4921ed80ce2049c1ab8863e1bda2',1,'OMPErrorCode.h']]],
  ['status_5fgmmptcp_5fport_5fclosed',['STATUS_GMMPTCP_PORT_CLOSED',['../_o_m_p_error_code_8h.html#a9eed871453f69c3fe6ad99a05df55840',1,'OMPErrorCode.h']]],
  ['status_5fmsptcp_5fdisconnected',['STATUS_MSPTCP_DISCONNECTED',['../_o_m_p_error_code_8h.html#a3784641fb0eadd1092dd497fe6831897',1,'OMPErrorCode.h']]],
  ['staus_5fao_5fcontrol_5fsend_5ffail',['STAUS_AO_CONTROL_SEND_FAIL',['../_o_m_p_error_code_8h.html#a4553a1958c360a8e046301de7fb4b46c',1,'OMPErrorCode.h']]]
];

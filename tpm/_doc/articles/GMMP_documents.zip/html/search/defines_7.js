var searchData=
[
  ['user_5fdefined_5fcontrol_5fmax',['User_defined_Control_Max',['../_define___control_8h.html#a381001ace59ccbca726bc4fbee8a59e5',1,'Define_Control.h']]],
  ['user_5fdefined_5fcontrol_5fmin',['User_defined_Control_Min',['../_define___control_8h.html#a5ca6bff30401cb02b62ddd7066f2e821',1,'Define_Control.h']]]
];

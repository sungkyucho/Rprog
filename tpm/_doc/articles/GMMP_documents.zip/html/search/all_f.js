var searchData=
[
  ['readtcp',['ReadTCP',['../_network_8c.html#a26e607a71c4d19ce0b6d2d63c72fb62e',1,'ReadTCP(char *pBuf, const int nMaxlen):&#160;Network.c'],['../_network_8h.html#a95530981177566800df6c67776b32237',1,'ReadTCP(char *_pBuf, const int _nMaxlen):&#160;Network.c']]],
  ['remote_5freq',['Remote_Req',['../struct_remote___req.html',1,'']]],
  ['remote_5frsp',['Remote_Rsp',['../struct_remote___rsp.html',1,'']]],
  ['reserved_5fmax',['Reserved_Max',['../_define___control_8h.html#a2848b5ca36f1a8732383caec25179d21',1,'Define_Control.h']]],
  ['reserved_5fmin',['Reserved_Min',['../_define___control_8h.html#a2268b47b072e80b5deb9bbb836f585ca',1,'Define_Control.h']]],
  ['runpausevalue',['RunPauseValue',['../struct_status_check.html#a6a3678f2f234384123cc163d3d06772b',1,'StatusCheck']]]
];

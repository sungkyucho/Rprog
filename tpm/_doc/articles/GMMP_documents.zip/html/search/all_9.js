var searchData=
[
  ['industrial_5freserved_5fmax',['Industrial_Reserved_Max',['../_define___control_8h.html#a66da91600bb006da852eb257b927b14f',1,'Define_Control.h']]],
  ['industrial_5freserved_5fmin',['Industrial_Reserved_Min',['../_define___control_8h.html#aff6a5b056a786781be259083e8a8693b',1,'Define_Control.h']]],
  ['initializaion',['Initializaion',['../_g_m_m_p_8c.html#a3ba7d66a7b45e118c463a1cb0946f1c7',1,'Initializaion(const char *pszServerIP, const int nPort, const char *pszDomainCode, const char *pszGWAuthID, const int nWriteLog, const int nErrorLevel, const int nNetwrokType, const char *pszLogFileName):&#160;GMMP.c'],['../_g_m_m_p_8h.html#a61bb3f57b9b7930853a0e7bc7c0951a8',1,'Initializaion(const char *pszServerIP, const int nPort, const char *pszDomainCode, const char *pszGWAuthID, const int nGMMPMode, const int nErrorLevel, const int nNetwrokType, const char *pszLogFileName):&#160;GMMP.c']]],
  ['initmemory',['InitMemory',['../_g_m_m_p_8c.html#a0919908e4e33d643479ce3d3a1c12f99',1,'InitMemory():&#160;GMMP.c'],['../_g_m_m_p_8h.html#a0919908e4e33d643479ce3d3a1c12f99',1,'InitMemory():&#160;GMMP.c']]],
  ['isbigendiansystem',['IsBigEndianSystem',['../_g_m_m_p___util_8c.html#ab7c10ae7541260d3a9f8708e67f51d8e',1,'IsBigEndianSystem(void):&#160;GMMP_Util.c'],['../_g_m_m_p___util_8h.html#ab7c10ae7541260d3a9f8708e67f51d8e',1,'IsBigEndianSystem(void):&#160;GMMP_Util.c']]]
];

var searchData=
[
  ['btoli',['btoli',['../_g_m_m_p___util_8c.html#a3f299224a2a5f4dc4e0ed6ffa846ddd6',1,'btoli(const int nInt):&#160;GMMP_Util.c'],['../_g_m_m_p___util_8h.html#a3f299224a2a5f4dc4e0ed6ffa846ddd6',1,'btoli(const int nInt):&#160;GMMP_Util.c']]],
  ['btols',['btols',['../_g_m_m_p___util_8c.html#aea7f450261d6b5ab8862bfaaaae0a1ca',1,'btols(const short nShort):&#160;GMMP_Util.c'],['../_g_m_m_p___util_8h.html#aea7f450261d6b5ab8862bfaaaae0a1ca',1,'btols(const short nShort):&#160;GMMP_Util.c']]]
];

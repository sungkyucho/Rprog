var searchData=
[
  ['readtcp',['ReadTCP',['../_network_8c.html#a26e607a71c4d19ce0b6d2d63c72fb62e',1,'ReadTCP(char *pBuf, const int nMaxlen):&#160;Network.c'],['../_network_8h.html#a95530981177566800df6c67776b32237',1,'ReadTCP(char *_pBuf, const int _nMaxlen):&#160;Network.c']]]
];

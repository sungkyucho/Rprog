var searchData=
[
  ['uninitializaion',['UnInitializaion',['../_g_m_m_p_8c.html#ab1c6d7ba4cc5a3c76f54cb616c3b1609',1,'UnInitializaion():&#160;GMMP.c'],['../_g_m_m_p_8h.html#ab1c6d7ba4cc5a3c76f54cb616c3b1609',1,'UnInitializaion():&#160;GMMP.c']]]
];

var searchData=
[
  ['m2m_20gw_2fdevice_20단말_20제어',['M2M GW/Device 단말 제어',['../group___g_m_m_p___control___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20주기_20보고',['M2M GW/Device 주기 보고',['../group___g_m_m_p___delivery___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20등록_20해지',['M2M GW/Device 등록 해지',['../group___g_m_m_p___de_registration___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20주기_20보호_20암호화',['M2M GW/Device 주기 보호 암호화',['../group___g_m_m_p___encryption___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20ftp_20info',['M2M GW/Device FTP Info',['../group___g_m_m_p___f_t_p___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20heartbeat',['M2M GW/Device Heartbeat',['../group___g_m_m_p___heartbeat___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20lob_20upload',['M2M GW/Device LOB Upload',['../group___g_m_m_p___l_o_b___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20long_20sentence',['M2M GW/Device Long Sentence',['../group___g_m_m_p___l_sentence___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20multimedia_20control',['M2M GW/Device Multimedia Control',['../group___g_m_m_p___multimedia___operation.html',1,'']]],
  ['m2m_20m2m_20gw_2fdevice_20제어_20결과_20보고',['M2M M2M GW/Device 제어 결과 보고',['../group___g_m_m_p___notification___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20profile_20info',['M2M GW/Device Profile Info',['../group___g_m_m_p___profile_info___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20등록',['M2M GW/Device 등록',['../group___g_m_m_p___registration___operation.html',1,'']]],
  ['m2m_20gw_2fdevice_20remote_20access_20info',['M2M GW/Device Remote Access Info',['../group___g_m_m_p___remote___operation.html',1,'']]],
  ['mallocbody',['MallocBody',['../_g_m_m_p___operation_8c.html#af999eaaca24c546526711fac1d40c873',1,'MallocBody(const char Type, int *nBodySize):&#160;GMMP_Operation.c'],['../_g_m_m_p___operation_8h.html#a3bb6186bbb49f583caaa98bb3c52aff2',1,'MallocBody(const char Type, int *nOutBufferSize):&#160;GMMP_Operation.c']]],
  ['mmurlinfo_5freq',['MMURLInfo_Req',['../struct_m_m_u_r_l_info___req.html',1,'']]],
  ['mmurlinfo_5frsp',['MMURLInfo_Rsp',['../struct_m_m_u_r_l_info___rsp.html',1,'']]],
  ['multiapp_5freq',['MultiApp_Req',['../struct_multi_app___req.html',1,'']]],
  ['multiapp_5frsp',['MultiApp_Rsp',['../struct_multi_app___rsp.html',1,'']]]
];

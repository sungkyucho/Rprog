var searchData=
[
  ['g_5fbisencryptioncontinue',['g_bIsEncryptionContinue',['../_g_m_m_p_8c.html#a77a72c8f97a7ec7dfd767862145b7d9c',1,'GMMP.c']]],
  ['g_5fcallfunctionregrecv',['g_CallFunctionRegRecv',['../_g_m_m_p_8c.html#af07b60a6bcd7d7c05b8a08fb40337547',1,'GMMP.c']]],
  ['g_5fnnetworkmode',['g_nNetworkMode',['../_g_m_m_p_8c.html#ad23eff33a95e684c4072b307995bd3ba',1,'GMMP.c']]],
  ['g_5fnserverport',['g_nServerPort',['../_define_8h.html#a8b8d7c7d32b9ef3a93bdbfd81cb2f407',1,'g_nServerPort():&#160;GMMP.c'],['../_g_m_m_p_8c.html#a8b8d7c7d32b9ef3a93bdbfd81cb2f407',1,'g_nServerPort():&#160;GMMP.c']]],
  ['g_5fszauthid',['g_szAuthID',['../_define_8h.html#a34f2452f9451f33d764745835a861eb3',1,'g_szAuthID():&#160;GMMP.c'],['../_g_m_m_p_8c.html#a34f2452f9451f33d764745835a861eb3',1,'g_szAuthID():&#160;GMMP.c']]],
  ['g_5fszauthkey',['g_szAuthKey',['../_define_8h.html#a288a4e6c5700a133f3f5a68add88dd0d',1,'g_szAuthKey():&#160;GMMP.c'],['../_g_m_m_p_8c.html#a288a4e6c5700a133f3f5a68add88dd0d',1,'g_szAuthKey():&#160;GMMP.c']]],
  ['g_5fszdomaincode',['g_szDomainCode',['../_define_8h.html#a0bcb04cb186dbfb38b9ab76f6ceed919',1,'g_szDomainCode():&#160;GMMP.c'],['../_g_m_m_p_8c.html#a0bcb04cb186dbfb38b9ab76f6ceed919',1,'g_szDomainCode():&#160;GMMP.c']]],
  ['g_5fszgwid',['g_szGWID',['../_define_8h.html#aece557a0ae0acc6c95c39985a0a45d0b',1,'g_szGWID():&#160;GMMP.c'],['../_g_m_m_p_8c.html#aece557a0ae0acc6c95c39985a0a45d0b',1,'g_szGWID():&#160;GMMP.c']]],
  ['g_5fszserverip',['g_szServerIP',['../_define_8h.html#aa1bca94787062c0066548cde6ef11b06',1,'g_szServerIP():&#160;GMMP.c'],['../_g_m_m_p_8c.html#aa1bca94787062c0066548cde6ef11b06',1,'g_szServerIP():&#160;GMMP.c']]]
];

var searchData=
[
  ['remote_5freq',['Remote_Req',['../struct_remote___req.html',1,'']]],
  ['remote_5frsp',['Remote_Rsp',['../struct_remote___rsp.html',1,'']]]
];
